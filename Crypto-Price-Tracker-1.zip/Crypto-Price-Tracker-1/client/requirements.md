## Packages
recharts | For rendering the crypto price charts (Area + Bar charts)
date-fns | For formatting dates and times on the chart axis

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}
